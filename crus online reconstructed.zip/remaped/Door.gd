extends KinematicBody

onready var NetworkBridge = Global.get_node("Multiplayer/NetworkBridge")

var PARTICLE = preload("res://Entities/Particles/Destruction_Particle.tscn")

export  var door_health = 100
export  var rotation_speed = 2
var open = false
var stop = true
var initrot = rotation
var rotation_counter = 0
var mesh_instance
var collision_shape
var collision = false
var found_overlap
var type = 1
var audio_player

var isDestroyed = false
var pose_revision = 0


func _ready():
	rset_config("global_transform",MultiplayerAPI.RPC_MODE_PUPPET)
	rset_config("door_health", MultiplayerAPI.RPC_MODE_PUPPET)
	NetworkBridge.register_rset(self, "global_transform", NetworkBridge.PERMISSION.SERVER)
	NetworkBridge.register_rset(self, "door_health", NetworkBridge.PERMISSION.SERVER)
	
	NetworkBridge.register_rpcs(self, [
		["_set_transform", NetworkBridge.PERMISSION.SERVER],
		["sync_door_pose", NetworkBridge.PERMISSION.SERVER],
		["remove_on_ready", NetworkBridge.PERMISSION.SERVER],
		["remove", NetworkBridge.PERMISSION.SERVER],
		["_get_transform", NetworkBridge.PERMISSION.ALL],
		["check_removed", NetworkBridge.PERMISSION.ALL],
		["network_destroy", NetworkBridge.PERMISSION.ALL],
		["network_damage", NetworkBridge.PERMISSION.ALL],
		["network_use", NetworkBridge.PERMISSION.ALL]
	])
	
	set_process(false)
	set_collision_layer_bit(8, 1)
	for child in get_children():
		if child is MeshInstance:
			mesh_instance = child
		if child is CollisionShape:
			collision_shape = child
	var t = mesh_instance.transform
	
	if mesh_instance.get_aabb().size.x > mesh_instance.get_aabb().size.z:
		global_transform.origin.x -= mesh_instance.get_aabb().position.x
		global_transform.origin.z -= mesh_instance.get_aabb().position.z + mesh_instance.get_aabb().size.z * 0.5
		t = t.translated(Vector3(mesh_instance.get_aabb().position.x, 0, mesh_instance.get_aabb().position.z + mesh_instance.get_aabb().size.z * 0.5))
	else :
		global_transform.origin.x -= mesh_instance.get_aabb().position.x + mesh_instance.get_aabb().size.x * 0.5
		global_transform.origin.z -= mesh_instance.get_aabb().position.z
		t = t.translated(Vector3(mesh_instance.get_aabb().position.x + mesh_instance.get_aabb().size.x * 0.5, 0, mesh_instance.get_aabb().position.z))
	
	mesh_instance.transform = t
	collision_shape.transform = t

	audio_player = AudioStreamPlayer3D.new()
	get_parent().call_deferred("add_child", audio_player)
	yield (get_tree(), "idle_frame")
	audio_player.global_transform.origin = global_transform.origin
	audio_player.stream = load("res://Sfx/Environment/doorkick.wav")
	audio_player.unit_size = 10
	audio_player.unit_db = 4
	audio_player.max_db = 4
	audio_player.pitch_scale = 0.6
	
	if NetworkBridge.check_connection() and not NetworkBridge.n_is_network_master(self):
		NetworkBridge.n_rpc(self, "_get_transform")
		NetworkBridge.n_rpc(self, "check_removed")

master func _get_transform(id):
	NetworkBridge.n_rpc_id(self, id, "sync_door_pose", [global_transform, pose_revision])

puppet func _set_transform(id, value, revision):
	if revision != pose_revision:
		return
	global_transform = value

puppet func sync_door_pose(id, value, revision):
	if revision < pose_revision:
		return
	pose_revision = revision
	global_transform = value

func _physics_process(delta):
	if NetworkBridge.n_is_network_master(self):
		if not open and not stop:
			var step = min(rotation_speed * delta, deg2rad(90 - rotation_counter))
			rotation.y += step
			rotation_counter += rad2deg(step)
			NetworkBridge.n_rpc_unreliable(self, "_set_transform", [global_transform, pose_revision])
		if open and not stop:
			var step = min(rotation_speed * delta, deg2rad(90 - rotation_counter))
			rotation.y -= step
			rotation_counter += rad2deg(step)
			NetworkBridge.n_rpc_unreliable(self, "_set_transform", [global_transform, pose_revision])
		if rotation_counter >= 89.999:
			rotation_counter = 0
			stop = true
			pose_revision += 1
			NetworkBridge.n_rpc(self, "sync_door_pose", [global_transform, pose_revision])

master func check_removed(id):
	if isDestroyed:
		NetworkBridge.n_rpc_id(self, id, "remove_on_ready")

func destroy(collision_n, collision_p):
	network_destroy(null, collision_n, collision_p)

master func network_destroy(id, collision_n, collision_p):
	if NetworkBridge.n_is_network_master(self):
		damage(200, collision_n, collision_p, Vector3.ZERO)
	else:
		NetworkBridge.n_rpc(self, "network_destroy", [collision_n, collision_p])

func damage(dmg, nrml, pos, shoot_pos):
	network_damage(null, dmg, nrml, pos, shoot_pos)

master func network_damage(id, damage, collision_n, collision_p, shooter_pos):
	if isDestroyed:
		return
	if NetworkBridge.n_is_network_master(self):
		door_health -= damage
		if door_health <= 0:
			remove(null, collision_n, collision_p)
			NetworkBridge.n_rpc(self, "remove", [collision_n, collision_p, true])
		NetworkBridge.n_rset(self, "door_health", door_health)
	else:
		NetworkBridge.n_rpc(self, "network_damage", [damage, collision_n, collision_p, shooter_pos])

func get_type():
	return type;

func use():
	network_use(null)
	
master func network_use(id):
	if NetworkBridge.n_is_network_master(self):
		stop = not stop
		open = not open
		pose_revision += 1
		NetworkBridge.n_rpc(self, "sync_door_pose", [global_transform, pose_revision])
	else:
		NetworkBridge.n_rpc(self, "network_use")

puppet func remove_on_ready(id):
	isDestroyed = true
	set_collision_layer_bit(0,false)
	set_collision_mask_bit(0,false)
	set_collision_layer_bit(8, false)
	hide()

puppet func remove(id, collision_n, collision_p, from_host = false):
	if isDestroyed:
		return
	isDestroyed = true
	audio_player.global_transform.origin = collision_p
	audio_player.play()
	var new_particle = PARTICLE.instance()
	get_parent().add_child(new_particle)
	new_particle.global_transform.origin = collision_p
	new_particle.look_at(global_transform.origin + collision_n * 5 + Vector3(1e-06, 0, 0), Vector3.UP)
	new_particle.material_override = mesh_instance.mesh.surface_get_material(0)
	new_particle.emitting = true
	set_collision_layer_bit(0,false)
	set_collision_mask_bit(0,false)
	set_collision_layer_bit(8, false)
	hide()
