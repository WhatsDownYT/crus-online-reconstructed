shader_type spatial;
render_mode depth_draw_opaque, cull_back;

uniform sampler2D albedo_texture : hint_albedo;
uniform float visibility : hint_range(0.0, 1.0) = 1.0;

float dither_value(vec2 position) {
	return fract(52.9829189 * fract(dot(floor(position), vec2(0.06711056, 0.00583715))));
}

void fragment() {
	vec4 tex = texture(albedo_texture, UV);
	if (tex.a < 0.5 || dither_value(FRAGCOORD.xy) >= visibility) {
		discard;
	}
	ALBEDO = tex.rgb;
	ROUGHNESS = 0.8;
}
