extends Reference

static func resolve(catalog, names):
	if typeof(names) != TYPE_ARRAY or names.size() != 4:
		return null
	var slots = ["head", "torso", "arms", "legs"]
	var result = {
		"stealth": false,
		"camo": 0.0,
		"cursed_torch": false,
		"multiplayer_camo": false,
		"multiplayer_stealth": false,
		"multiplayer_sedative": false,
		"multiplayer_first_aid": false,
		"multiplayer_cursed_torch": false,
		"multiplayer_augmented_arms": false,
		"sedative_immune": false
	}
	for index in range(4):
		if typeof(names[index]) != TYPE_STRING:
			return null
		if names[index] == "N/A":
			continue
		var found = false
		for implant in catalog:
			if implant.i_name == names[index] and implant.get(slots[index]):
				found = true
				if index == 1:
					result.stealth = implant.stealth
					result.camo = implant.camo
					result.multiplayer_camo = implant.multiplayer_camo
					result.multiplayer_stealth = implant.multiplayer_stealth
					result.sedative_immune = implant.terror or implant.orbsuit
				if index == 2:
					result.cursed_torch = implant.cursed_torch
					result.multiplayer_sedative = implant.multiplayer_sedative
					result.multiplayer_first_aid = implant.multiplayer_first_aid
					result.multiplayer_cursed_torch = implant.multiplayer_cursed_torch
					result.multiplayer_augmented_arms = implant.multiplayer_augmented_arms
				break
		if not found:
			return null
	return result
