# Cruelty Squad Online

<div align="center">

<img src="crus_online_logo.png" width="600" alt="Cruelty Squad Online logo">

English | [Русский](README_RU.md) 

</div>

> [!WARNING]
> This modification is in open **Beta** testing
> 
> You may encounter bugs and poor performance.

## About
Cruelty Squad Online (CruS Online) is a huge modification for game [Cruelty Squad](https://store.steampowered.com/app/1388770/Cruelty_Squad/) that add a lobby style Steam and LAN multiplayer

## Installation
CruS Online is installed in the same way as other modifications

1. Install [CruS Modloader](https://github.com/CruS-Modding-Infrastructure/crus-modloader)
2. Download latest version of CruS Online from [here](https://github.com/TriggeredP/crus-online/releases)
3. Extract CruS Online folder into this directory: `%appdata%\Godot\app_userdata\Cruelty Squad\mods`
4. Launch the game

> [!CAUTION]
> CruS Online is currently incompatible with other modifications

## Hosting lobby
This modification provides two ways to connect players.:

1. Steam
2. LAN

**Steam:**
To create a lobby in the game, you need to:

1. Open the CruS Online menu (The second icon in the main menu)
2. Select Steam connection mode
3. Click on the 'Create` button to create a lobby

**LAN:**
There are two ways to create a lobby via LAN connection:

1. Port forwarding
2. Using a VPN software (like Radmin VPN)

The best way would be to port forwarding because this will help improve performance, but if you can't forward ports, you can use Radmin VPN or similar applications

Also, the host must have a good computer, otherwise it may affect performance

To create a lobby in the game, you need to:

1. Open the CruS Online menu (The second icon in the main menu)
2. Go to the `Host` tab and set the port (It doesn't matter if Radmin VPN is used)
3. Go to the `Main` tab and click to a `Host` button
4. Share IP and port with those you are going to play with

## Connecting to lobby
After the host has created the lobby, the players must:

**Steam:**

1. Open the CruS Online menu (The second icon in the main menu)
2. Select Steam connection mode
3. Select the lobby from the list (Or receive an invitation from the host)
4. Click on the `Join` button to connect to the lobby

**LAN:**

1. Open the CruS Online menu (The second icon in the main menu)
2. Enter the IP and port received from the host
3. Press `Join` button

## Starting game
After everyone has entered the lobby, players must choose weapons and implants

Once all the players are ready the host must select a level and press `Start misson` button to play map from the main game

While hosting a lobby, the `Modes` tab lets the host choose the active multiplayer mode.

After the game starts, players will not be able to join the lobby

## Usefull information

You can change the nickname, color and skin in the `Player` tab
The `Host` tab has a bunch of parameters that can be changed

## Links
My site: https://triggeredp.site

YouTube: https://www.youtube.com/@triggeredp

Boosty: https://boosty.to/triggeredp
