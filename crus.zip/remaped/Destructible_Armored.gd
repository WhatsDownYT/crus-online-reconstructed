extends KinematicBody

onready var NetworkBridge = Global.get_node("Multiplayer/NetworkBridge")

var PARTICLE = preload("res://Entities/Particles/Destruction_Particle.tscn")

export  var door_health = 100
var mesh_instance
var type = 1
var audio_player

var isDestroyed = false

var destroy_check_timer

func _ready():
	rset_config("door_health", MultiplayerAPI.RPC_MODE_PUPPET)
	NetworkBridge.register_rset(self, "door_health", NetworkBridge.PERMISSION.SERVER)
	
	NetworkBridge.register_rpcs(self, [
		["remove_on_ready", NetworkBridge.PERMISSION.SERVER],
		["remove", NetworkBridge.PERMISSION.SERVER],
		["check_removed", NetworkBridge.PERMISSION.ALL],
		["network_piercing_damage", NetworkBridge.PERMISSION.ALL]
	])
	
	for child in get_children():
		if child is MeshInstance:
			mesh_instance = child
	var t = mesh_instance.transform
	audio_player = AudioStreamPlayer3D.new()
	get_parent().call_deferred("add_child", audio_player)
	yield (get_tree(), "idle_frame")
	audio_player.global_transform.origin = global_transform.origin
	audio_player.stream = load("res://Sfx/Environment/doorkick.wav")
	audio_player.unit_size = 10
	audio_player.unit_db = 2
	audio_player.max_db = 3
	set_collision_layer_bit(8, 1)
	
	destroy_check_timer = Timer.new()
	destroy_check_timer.wait_time = 2.0
	destroy_check_timer.one_shot = true
	destroy_check_timer.connect("timeout", self, "respawn")

	if NetworkBridge.check_connection() and not NetworkBridge.is_world_authority():
		NetworkBridge.request_host(self, "check_removed")

master func check_removed(id):
	if isDestroyed:
		NetworkBridge.n_rpc_id(self, id, "remove_on_ready")

func piercing_damage(damage, collision_n, collision_p, shooter_pos):
	network_piercing_damage(null, damage, collision_n, collision_p, shooter_pos)

master func network_piercing_damage(id, damage, collision_n, collision_p, shooter_pos):
	if NetworkBridge.n_is_network_master(self):
		door_health -= damage
		if door_health <= 0:
			remove(null, collision_n, collision_p)
			NetworkBridge.n_rpc(self, "remove", [collision_n, collision_p, true])
		NetworkBridge.n_rset(self, "door_health", door_health)
	else:
		door_health -= damage
		if door_health <= 0:
			remove(null, collision_n, collision_p)
			destroy_check_timer.start()
		NetworkBridge.n_rpc(self, "network_piercing_damage", [damage, collision_n, collision_p, shooter_pos])

func get_type():
	return type;

puppet func remove_on_ready(id):
	set_collision_layer_bit(0,false)
	set_collision_mask_bit(0,false)
	set_collision_layer_bit(8, false)
	hide()

func player_use():
	Global.player.UI.notify("Small cracks permeate the surface", Color(1, 1, 1))

puppet func remove(id, collision_n, collision_p, from_host = false):
	if not visible and from_host:
		destroy_check_timer.stop()
	else:
		isDestroyed = true
		audio_player.global_transform.origin = collision_p
		audio_player.play()
		var new_particle = PARTICLE.instance()
		get_parent().add_child(new_particle)
		new_particle.global_transform.origin = collision_p
		new_particle.look_at(global_transform.origin + collision_n * 5 + Vector3(1e-06, 0, 0), Vector3.UP)
		new_particle.material_override = mesh_instance.mesh.surface_get_material(0)
		new_particle.emitting = true
		set_collision_layer_bit(0,false)
		set_collision_mask_bit(0,false)
		hide()

func respawn():
	isDestroyed = false
	set_collision_layer_bit(0,true)
	set_collision_mask_bit(0,true)
	show()
